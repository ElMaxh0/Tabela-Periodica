import React from "react";
import { useSelectedElement } from "../../hooks/selectedIten";

export default function ItenData(){
    const {SelectedElementid, setSelectedElementid}= useSelectedElement();

    return(
        <>
        <div>
            {SelectedElementid.nome}
            {SelectedElementid.densidade}
            {SelectedElementid.numeroatomico}
            {SelectedElementid.eletronicconfig2}
            {SelectedElementid.massaatomica}
        </div>
        </>
    )
}